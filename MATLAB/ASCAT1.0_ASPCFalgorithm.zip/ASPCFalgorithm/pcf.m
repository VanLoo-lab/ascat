% 
% PCF filter for aCGH data (v. 23.09.2008)
%
%

function yhat = pcf(y, kmin, gamma, wts)

ymean = mean(y);
y = y - ymean;
N = length(y);
yhat = zeros(N,1);

% Data are in y(1..N) = y[first..first+N-1] where first = 1
% Results are put in yhat(1..N) = yhat(colFrom..colFrom+N-1)
% where colFrom = 1;

% Very short sequences are estimated by average
if N == 1
    yhat(1) = y(1);
    return
end

if N < 2*kmin
    yhat = repmat(mean(y),N,1);
    return
end

% Find initSum, initKvad, initAve for segment y[1..kmin]
initSum = sum(y(1:kmin));
initKvad = sum(y(1:kmin).^2);
initAve = initSum/kmin;

% Define vector of best costs
bestCost = zeros(N,1);
bestCost(kmin) = initKvad - initSum*initAve;

% Define vector of best splits
bestSplit = zeros(N,1);
bestSplit(kmin) = 0; % Previous (imaginary) segment ends at 0

% Define vector of best averages
bestAver = zeros(N,1);
bestAver(1:kmin) = initAve;

% Define auxiliary variables
newSum = initSum;
newAver = initAve;
newKvad = initKvad;
newSSQ = 0;

% We have to treat the region y(1..2*kmin-1) separately, as it 
% cannot be split into two full segments
for k = kmin+1 : 2*kmin-1
   newSum = newSum + y(k);
   newAver = newSum / k;
   newKvad = newKvad + y(k)^2;
   newSSQ = newKvad - newSum*newAver;
   bestCost(k) = newSSQ;
   bestSplit(k) = 0; % Previous (imaginary) segments ends at 0
   bestAver(k) = newAver;
end

for n = 2*kmin : N
   % Now bestCost(r) is the optimal value over y(1..r), r = 1..n-1
   % We want to find bestCost(n). To do this, we seek the best
   % split y(1..n) = y(1..j-1) + y(j..n) where the latter is
   % a primitive segment. We refer to j-1 as the split point.
   % Allowed split points are {kmin..n-kmin}
   
   % First consider split = n-kmin with 
   % bestCost(n) = bestCost(n-kmin) + ssq + gamma
   newSum = sum(y(n-kmin+1:n));
   newKvad = sum(y(n-kmin+1:n).^2);
   newAver = newSum / kmin;
   newSSQ = newKvad - newSum * newAver;
   split = n - kmin;  % Best split so far
   aver = newAver;
   cost = bestCost(n-kmin) + newSSQ + gamma;
   
   % Now consider remaining splits {kmin..n-kmin-1}
   for j = n-kmin:-1:kmin+1
      % Consider split y(1..j-1) + y(j..n) where the latter is primitive
      yj = y(j);
      newSum = newSum + yj;
      newAver = newSum / (n-j+1);
      newKvad = newKvad + yj^2;
      newSSQ = newKvad - newSum * newAver;
      newCost = bestCost(j-1) + newSSQ + gamma;
      if newCost < cost
         split = j-1;
         cost = newCost;
         aver = newAver;
      end
   end
   
   % Best split is y(1..split) + y(split+1..n) under the condition
   % that kmin <= split <= n - kmin. We check if not making a
   % split is better
   totAver = (newSum + initSum) / (n+1);
   totCost = (newKvad + initKvad) - (n+1)*totAver^2;
   if totCost < cost
       split = 0;
       cost = totCost;
       aver = totAver;
   end
   
   % We now have the optimal split of y(1..n)
   bestCost(n) = cost;
   bestAver(n) = aver;
   bestSplit(n) = split;
end

% Trace back
n = N;
nlevels = 0;
while n > 0
   yhat(bestSplit(n)+1:n) = bestAver(n);
   n = bestSplit(n);
   nlevels = nlevels + 1;    
end

yhat = ymean + yhat;


