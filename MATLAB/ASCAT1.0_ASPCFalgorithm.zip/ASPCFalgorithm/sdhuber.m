function sd = sdhuber(y) 
    tau = 1.645;
    s0 = 1.4826 * mad(y,1);
    % rhs = mean(psi(randn(10^7,1), tau).^2);
    rhs = 0.8315;  % Pre-calculated value for tau=1.645
    n = length(y)-1;
    options = optimset('Display','off'); 
    sd = fsolve(@(s)sum(psi(y/s,tau).^2)-(n-1)*rhs, s0, options);
end
