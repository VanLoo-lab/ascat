function [R sens spec] = concordance(A, thetaA, B, thetaB)

R = zeros(3,3);
R(1,1) = sum(sum(A < -thetaA & B < -thetaB));
R(1,2) = sum(sum(A < -thetaA & abs(B) <= thetaB));
R(1,3) = sum(sum(A < -thetaA & B > thetaB));
R(2,1) = sum(sum(abs(A) <= thetaA & B < -thetaB));
R(2,2) = sum(sum(abs(A) <= thetaA & abs(B) <= thetaB));
R(2,3) = sum(sum(abs(A) <= thetaA & B > thetaB));
R(3,1) = sum(sum(A > thetaA & B < -thetaB));
R(3,2) = sum(sum(A > thetaA & abs(B) <= thetaB));
R(3,3) = sum(sum(A > thetaA & B > thetaB));
TP = R(3,3) + R(1,1);
TN = R(2,2);
FP = R(2,1) + R(3,1) + R(1,3) + R(2,3);
FN = R(1,2) + R(3,2);
sens = TP/(TP+FN);
spec = TN/(FP+TN);


