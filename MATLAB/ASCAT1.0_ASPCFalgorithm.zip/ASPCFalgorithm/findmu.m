function mu = findmu(mu0, sd, x)

n = numel(x);
options = optimset('GradObj', 'on');

mu = fminunc(@myfun, mu0, options);

    function [f g] = myfun(mu)
       a = exp(-(x-repmat(mu,n,1)).^2 / sd^2);
       b = exp(-(x+repmat(mu,n,1)).^2 / sd^2);
       f = -sum(log(a + b)); %+ 750*mu*mu;
       
       A = 2*(x-repmat(mu,n,1)).*a - 2*(x+repmat(mu,n,1)).*b;
       B = sd^2 * (a + b);
       g = -sum(A ./ B);
    end
end