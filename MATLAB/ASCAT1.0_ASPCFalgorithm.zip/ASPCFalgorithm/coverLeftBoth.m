function last = coverLeftBoth(k, first, obs1, obs2)
    k1 = coverLeft(k,first,obs1);
    k2 = coverLeft(k,first,obs2);
    last = min(k1,k2);
end
