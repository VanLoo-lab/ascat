function last = coverRight(k, first, obs)
    n = numel(obs);
    i = first;
    cnt = 0;
    while (cnt < k && i <= n) 
       if obs(i) > 0
           cnt = cnt + 1;
       end
       i = i + 1;
    end
    last = i - 1;
end
