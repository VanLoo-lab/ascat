% Read data from file
cd('C:\Ole Chr\DNR\Peter');
logR = readtable('Example.txt', 2, 2, 'decimal', 1366);
allB = readtable('Example.txt', 3, 3, 'decimal', 1366);
p = size(logR,1);
k = 1:p;

% Plot B-allele frequency
figure(1)
hi = allB >= 0.5;
lo = allB < 0.5;
plot(k(lo), allB(lo), 'g.'); hold on
plot(k(hi), allB(hi), 'r.');
plot([1,p], [0.5,0.5], 'k-');

% Flip the data around the line y = 0.5
allBflip = allB;
allBflip(allB > 0.5) = 1 - allB(allB > 0.5);

% Find yhat and sd around local mean for flipped data
[ywin sdev] = pcfwins(allBflip, 2.5, 5, 1);
yhat = pcf(ywin, 5, 12*sdev^2);

% Plot result on unflipped data
plot(k, yhat, 'g-');
plot(k, 1-yhat, 'r-');

% On each segment compute sd of unflipped data
dy = diff(yhat);
frst = [1; 1+find(dy ~= 0)];
last = [find(dy ~= 0); p];
nseg = numel(frst);
res = zeros(nseg,2);
for i = 1:nseg
   yi1 = allB(frst(i):last(i));
   yi2 = allBflip(frst(i):last(i))-yhat(frst(i):last(i)); 
   [h,pval] = kstest((yi1-0.5)/sdev);
   ['Segment ' num2str(i) ': ' ...
       num2str(1.4826*mad(yi1,1)) ...
       ' - ' ...
       num2str(1.4826*mad(yi2,1)) ...
       ' - ' ...
       num2str(pval)] 
    res(i,:) = [1.4826*mad(yi1,1), 1.4826*mad(yi2,1)];
end

% Plot diagnostics 
figure(2)
plot(res(:,1), res(:,2), 'o'); hold on
axis([0 0.35 0 0.35])
plot([0 0.35], [0 0.35], '-')
xlabel('SD unflipped');
ylabel('SD flipped');



