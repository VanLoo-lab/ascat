function x = readtable(fname, firstcol, lastcol, dtype, nrows)

ncols = lastcol - firstcol + 1;

if strcmp(dtype, 'integer')
    dt = '%d';
elseif strcmp(dtype, 'decimal')
    dt = '%f';
else
    dt = '%s';
end

form1 = '';
for i = 1:firstcol-1
    form1 = [form1 ' %s'];
end

form2 = dt;
for i = 2:ncols
    form2 = [form2 ' ' dt];
end

formatstring = [form1 ' ' form2 '%*[^\n]'];

fid = fopen(fname);
C = textscan(fid, formatstring, 'HeaderLines', 1, 'Delimiter', '\t');
x = zeros(nrows, ncols);

for j = 1:ncols
    tmp = C{firstcol+j-1};
    for i = 1:nrows
        x(i,j) = tmp(i);
    end
end

