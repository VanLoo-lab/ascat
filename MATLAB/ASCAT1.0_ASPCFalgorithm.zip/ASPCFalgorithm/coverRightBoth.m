function last = coverRightBoth(k, first, obs1, obs2)
    k1 = coverRight(k,first,obs1);
    k2 = coverRight(k,first,obs2);
    last = max(k1,k2);
end
