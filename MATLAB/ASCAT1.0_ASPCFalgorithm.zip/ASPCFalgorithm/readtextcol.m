function x = readtextcol(fname, col)

dt = '%s';
form1 = '';
for i = 1:col-1
    form1 = [form1 ' %s'];
end
form2 = dt;
formatstring = [form1 ' ' form2 '%*[^\n]'];

fid = fopen(fname);
C = textscan(fid, formatstring, 'HeaderLines', 1, 'Delimiter', '\t');
x = C{col};

