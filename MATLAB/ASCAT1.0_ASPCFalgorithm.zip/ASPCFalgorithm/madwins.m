% 
% MAD winsorization of CGH data (v. 16.2.2008)
%
% This algorithm is a supplement to the paper: Liest�l, Baumbusch, 
% B�rresen-Dale and Lingj�rde. Outliers and detection of copy number 
% changes (2008).
%
% Input:
%    y         Array of CGH values
%    tau       Winsorization threshold (a typical value would be tau = 2.5)
% Output:
%    ywin      Array of winsorized CGH values
%    sdev      Estimated standard deviation
%    outliers  Array with outlier status (-1/+1=outlier, 0=not outlier)
%
% Version: OCL, Feb 2008

function [ywin sdev outliers] = madwins(y, tau)

% Step 1: Estimate trend
yhat = medianfilter(y, 25);

% Step 2: Estimate scale
sdev = 1.4826 * mad(y-yhat, 1);

% Step 3: Obtain winsorized observations
ywin = yhat + psi(y-yhat, tau*sdev);

% Step 4: Flag outliers
outliers = zeros(length(y), 1);
outliers(y > ywin) = 1;
outliers(y < ywin) = -1;
