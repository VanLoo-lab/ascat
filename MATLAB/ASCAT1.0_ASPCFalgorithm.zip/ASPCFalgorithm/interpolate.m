% 
% Constant interpolation
%
% The vectors x and y should have the same length and the values of x
% should be in non-decreasing order x(1) <= x(2) <= .... <= x(n). A
% vector of interpolation values yint is formed by constant interpolation 
% of the data (x,y) in the points given in the vector xint. 

function yint = interpolate(xint, x, y)

n = length(xint);
yint = zeros(n,1);

for i = 1:n
   k = find(xint(i) < x, 1);
   if numel(k) > 0
       if k > 1
           if xint(i) - x(k-1) < x(k) - xint(i)
               yint(i) = y(k-1); 
           else
               yint(i) = y(k);
           end
       else
           yint(i) = y(1);
       end
   else
      yint(i) = y(length(y)); 
   end
end
