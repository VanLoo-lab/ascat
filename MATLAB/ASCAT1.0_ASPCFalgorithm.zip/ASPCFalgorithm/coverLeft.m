function last = coverLeft(k, first, obs)
    i = first;
    cnt = 0;
    while (cnt < k && i > 0) 
       if obs(i) > 0
           cnt = cnt + 1;
       end
       i = i - 1;
    end
    last = i + 1;
end
