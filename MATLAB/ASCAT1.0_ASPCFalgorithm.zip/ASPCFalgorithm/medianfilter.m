% 
% Median smoother (v. 16.2.2008)
%
% This algorithm is a supplement to the paper: Liest�l, Baumbusch, 
% B�rresen-Dale and Lingj�rde. Outliers and detection of copy number 
% changes (2008).
%

function xhat = medianfilter(x, k)

widt = 2*k + 1;

N = length(x);
xhat = zeros(N,1);   % Result vector
cent = k + 1;        % Centre element of xarr vector

% First sort the first widt elements
% They are put in xarr, with indices in indx
[xarr,indx] = sort(x(1:widt));

% Set initial segment of xhat
xhat(1:cent) = xarr(cent);

% Compute main segment of xhat
for i = cent+1 : N-cent
   % Window xarr contains indices (i-1)-(cent-1) to (i-1)+(cent-1):
   %   x(i-cent..i+cent-2)
   % Want now to shift window one step to the right:
   %   x(i-cent+1..i+cent-1)
   % To do this, we:
   %   - throw out of xarr the value x(i-cent)
   %   - insert in xarr the value x(i+cent-1)
   % while keeping the vector xarr sorted.
   
   outPos = find(indx == i-cent); % Position in xarr of element x(i-cent)
   newVal = x(i+cent-1);          % Value to insert in xarr
   if newVal > xarr(outPos)
      % New value should be inserted in position range outPos..widt
      m = outPos + 1;
      while m <= widt && newVal > xarr(m)
          xarr(m-1) = xarr(m);
          indx(m-1) = indx(m);
          m = m + 1;
      end
      xarr(m-1) = newVal;
      indx(m-1) = i+cent-1;
   else
       % New value should be inserted in position range 1..outPos
       m = outPos - 1;
       while m >= 1 && newVal < xarr(m)
          xarr(m+1) = xarr(m);
          indx(m+1) = indx(m);
          m = m - 1;
       end
       xarr(m+1) = newVal;
       indx(m+1) = i+cent-1;
   end
   xhat(i) = xarr(cent);
end

% Set final segment of xhat
xhat(N-cent+1:N) = xarr(cent);


