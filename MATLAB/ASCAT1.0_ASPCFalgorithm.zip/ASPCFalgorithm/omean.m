function v = omean(x, obs)
    v = sum(x .* obs) / sum(obs);
end