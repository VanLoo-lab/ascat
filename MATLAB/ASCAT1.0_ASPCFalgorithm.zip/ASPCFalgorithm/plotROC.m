function [AUC sens spec] = plotROC(A, thetaA, B, thetaB, ptitle)
m = length(thetaA);
n = length(thetaB);
sens = zeros(n,m);
spec = zeros(n,m);
AUC = zeros(m,1);
for j = 1:m
    if j > 1 
        hold on
    end
    for i = 1:n
        [R sens(i,j) spec(i,j)] = concordance(A, thetaA(j), B, thetaB(i));
        if i > 1
            area = (sens(i-1,j)+sens(i,j))*(spec(i,j)-spec(i-1,j))/2;
            AUC(j) = AUC(j) + area;
        end
    end
    plot(1-spec, sens, '.-');
end
hold off
xlabel('1-specificity');
ylabel('sensitivity');
if nargin < 5
    title('ROC curve');
else
    title(ptitle);
end
