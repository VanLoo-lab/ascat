% 
% Enhanced bivariate PCF filter for aCGH data (v. 12.03.2009)
%
%

function [yhat1, yhat2] = aspcf(logR, allB, kmin, gamma)

N = numel(logR);

% Define missing indicator vectors
m1 = ones(N,1);  % 0 = missing, 1 = observed (no missing in logR)
m2 = allB >= 0;  % 0 = missing, 1 = observed (-1 in allB means missing)

% Winsorize logR data and determine sd1
%y1 = logR;
%sd1 = 0.2;
[y1 sd1] = pcfwins(logR, 2.5, 5, 1);

% Flip B-allele data around the line y = 0.5 and determine sd2
allBflip = allB;
allBflip(allB > 0.5) = 1 - allB(allB > 0.5);
y2 = allBflip;
%sd2 = 0.1;
[tmp sd2] = pcfwins(y2(m2), 2.5, 5, 1);

% Mean-center response variables
ymean1 = omean(y1, m1);
y1 = y1 - ymean1;
ymean2 = omean(y2, m2);
y2 = y2 - ymean2;

% Plug in zeros for missing values in y2
y2(~m2) = 0;     

% Create vector t of unique design points as well as two associated
% vectors y1 and y2 with response values (may be missing for one
% of the two, but never for both) and two associated vectors m1 and m2 
% giving missing status

yhat1 = zeros(N,1);
yhat2 = zeros(N,1);

% Data are in y1(1..N) and y2(1..N)

% Very short sequences are estimated by average
if N == 1
    yhat1(1) = y1(1);
    yhat2(1) = y2(1);
    return
end

if N < 2*kmin
    yhat1 = repmat(omean(y1,m1),N,1);
    yhat2 = repmat(omean(y2,m2),N,1);
    return
end

% Find initSum, initKvad, initAve for segment y[1..kmin]
initSum1 = sum(y1(1:kmin));
initKvad1 = sum(y1(1:kmin).^2);
initAve1 = div(initSum1, sum(m1(1:kmin)));
initSum2 = sum(y2(1:kmin));
initKvad2 = sum(y2(1:kmin).^2);
initAve2 = div(initSum2, sum(m2(1:kmin)));

% Define vector of best costs
bestCost = zeros(N,1);
SSQ1 = (initKvad1 - initSum1*initAve1)/sd1^2;
SSQ2 = (initKvad2 - initSum2*initAve2)/sd2^2;
if sum(m1(1:kmin)) < 3
    SSQ1 = SSQ2;
elseif sum(m2(1:kmin)) < 3
    SSQ2 = SSQ1;
end
bestCost(kmin) = SSQ1 + SSQ2;

% Define vector of best splits
bestSplit = zeros(N,1);
bestSplit(kmin) = 0; % Previous (imaginary) segment ends at 0

% Define vector of best averages
bestAver1 = zeros(N,1);
bestAver2 = zeros(N,1);
bestAver1(1:kmin) = initAve1;
bestAver2(1:kmin) = initAve2;

% Define auxiliary variables
newSum1 = initSum1;
newAver1 = initAve1;
newKvad1 = initKvad1;
SSQ1 = 0;
newSum2 = initSum2;
newAver2 = initAve2;
newKvad2 = initKvad2;
SSQ2 = 0;

% We have to treat the region y(1..2*kmin-1) separately, as it 
% cannot be split into two full segments

for k = kmin+1 : 2*kmin-1
   newSum1 = newSum1 + y1(k);
   newAver1 = div(newSum1, sum(m1(1:k)));
   newKvad1 = newKvad1 + y1(k)^2;
   SSQ1 = (newKvad1 - newSum1*newAver1)/sd1^2;
   newSum2 = newSum2 + y2(k);
   newAver2 = div(newSum2, sum(m2(1:k)));
   newKvad2 = newKvad2 + y2(k)^2;
   SSQ2 = (newKvad2 - newSum2*newAver2)/sd2^2;
   if sum(m1(1:k)) < 3
       SSQ1 = SSQ2;
   elseif sum(m2(1:k)) < 3
       SSQ2 = SSQ1;
   end
   bestCost(k) = SSQ1 + SSQ2;
   bestSplit(k) = 0; % Previous (imaginary) segments ends at 0
   bestAver1(k) = newAver1;
   bestAver2(k) = newAver2;
end

for n = 2*kmin : N
   % Now bestCost(r) is the optimal value over y(1..r), r = 1..n-1
   % We want to find bestCost(n). To do this, we seek the best
   % split y(1..n) = y(1..j-1) + y(j..n) where the latter is
   % a primitive segment. We refer to j-1 as the split point.
   % Allowed split points are {kmin..n-kmin}
   
   % First consider split = n-kmin with 
   % bestCost(n) = bestCost(n-kmin) + ssq + gamma
   n0 = n-kmin+1;
   newSum1 = sum(y1(n0:n));
   newKvad1 = sum(y1(n0:n).^2);
   newAver1 = div(newSum1, sum(m1(n0:n)));
   SSQ1 = (newKvad1 - newSum1 * newAver1)/sd1^2;
   newSum2 = sum(y2(n0:n));
   newKvad2 = sum(y2(n0:n).^2);
   newAver2 = div(newSum2, sum(m2(n0:n)));
   SSQ2 = (newKvad2 - newSum2 * newAver2)/sd2^2;
   if sum(m1(n0:n)) < 3
       SSQ1 = SSQ2;
   elseif sum(m2(n0:n)) < 3
       SSQ2 = SSQ1;
   end
   aver1 = newAver1;
   aver2 = newAver2;
   
   split = n0 - 1;  % Best split so far
   cost = bestCost(n0-1) + SSQ1 + SSQ2 + gamma;
   
   % Now consider remaining splits {kmin..n-kmin-1}
   for j = n0-1:-1:kmin+1  % j = left endpoint of last segment
      % Consider split y(1..j-1) + y(j..n) where the latter is primitive
      y1j = y1(j);
      newSum1 = newSum1 + y1j;
      newAver1 = div(newSum1, sum(m1(j:n)));
      newKvad1 = newKvad1 + y1j^2;
      SSQ1 = (newKvad1 - newSum1 * newAver1)/sd1^2;
      y2j = y2(j);
      newSum2 = newSum2 + y2j;
      newAver2 = div(newSum2, sum(m2(j:n)));
      newKvad2 = newKvad2 + y2j^2;
      SSQ2 = (newKvad2 - newSum2 * newAver2)/sd2^2;
      if sum(m1(j:n)) < 3
          SSQ1 = SSQ2;
      elseif sum(m2(j:n)) < 3
          SSQ2 = SSQ1;
      end
      newCost = bestCost(j-1) + SSQ1 + SSQ2 + gamma;
      if newCost < cost
         split = j-1;
         cost = newCost;
         aver1 = newAver1;
         aver2 = newAver2;
      end
   end
   
   % Best split is y(1..split) + y(split+1..n) under the condition
   % that kmin <= split <= n - kmin. We check if not making a
   % split is better
   totAver1 = div(newSum1 + initSum1, sum(m1(1:n)));
   totAver2 = div(newSum2 + initSum2, sum(m2(1:n)));
   SSQ1 = ((newKvad1 + initKvad1) - sum(m1(1:n))*totAver1^2)/sd1^2;
   SSQ2 = ((newKvad2 + initKvad2) - sum(m2(1:n))*totAver2^2)/sd2^2;
   if sum(m1(1:n)) < 3
      SSQ1 = SSQ2;
   elseif sum(m2(1:n)) < 3
      SSQ2 = SSQ1;
   end
   totCost = SSQ1 + SSQ2;
   if totCost < cost
       split = 0;
       cost = totCost;
       aver1 = totAver1;
       aver2 = totAver2;
   end
   
   % We now have the optimal split of y(1..n)
   bestCost(n) = cost;
   bestAver1(n) = aver1;
   bestAver2(n) = aver2;
   bestSplit(n) = split;
end

% Trace back
n = N;
nlevels = 0;
while n > 0
   yhat1(bestSplit(n)+1:n) = bestAver1(n);
   yhat2(bestSplit(n)+1:n) = bestAver2(n);
   n = bestSplit(n);
   nlevels = nlevels + 1;    
end

yhat1 = ymean1 + yhat1;
yhat2 = ymean2 + yhat2;

% On each segment calculate mean of unflipped B allele data
dy = diff(yhat2);
frst = [1; 1+find(dy ~= 0)];
last = [find(dy ~= 0); N];
nseg = numel(frst);
for i = 1:nseg
    yi2 = allB(frst(i):last(i));
    yi2 = yi2(m2(frst(i):last(i)))
    % Center data around zero (by subtracting 0.5) and estimate mean
    mu = findmu(0.2, sd2, yi2-repmat(0.5,size(yi2,1),size(yi2,2)));
    % Print segment number, mean value, standard deviation of flipped
    % data (across whole arm) and standard deviation of mixture
    % distribution. If the two latter deviate much there are likely
    % to be two branches, otherwise there is likely on branch.
    [i mu sd2 sqrt(sd2^2+mu^2)]
    % Make a (slightly arbitrary) decision concerning branches
    % This may be improved by a test of equal variances
    if sqrt(sd2^2+mu^2) < 2*sd2
        mu = 0;
    end
    yhat2(frst(i):last(i)) = repmat(mu+0.5,last(i)-frst(i)+1,1);
end

% On each segment compute sd of unflipped B allele data
% dy = diff(yhat2);
% frst = [1; 1+find(dy ~= 0)];
% last = [find(dy ~= 0); N];
% nseg = numel(frst);
% for i = 1:nseg
%    yi1 = allBflip(frst(i):last(i))-yhat2(frst(i):last(i)); 
%    yi1 = yi1(m2(frst(i):last(i)));
%    yi2 = allB(frst(i):last(i));
%    yi2 = yi2(m2(frst(i):last(i)));
%    if numel(yi2) > 20
%         [h,pval] = kstest((yi2-0.5)/sd2);
%         ['Segment ' num2str(i) ': ' ...
%             num2str(1.4826*mad(yi1,1)) ...
%             ' - ' ...
%             num2str(1.4826*mad(yi2,1)) ...
%             ' - ' ...
%             num2str(pval) ...
%              ' - ' ...
%         num2str(last(i)-frst(i)+1)] 
%         if numel(yi2) > 30 && pval > 0.0001
%            yhat2(frst(i):last(i)) = 0.5;
%         end
%    end
% end



