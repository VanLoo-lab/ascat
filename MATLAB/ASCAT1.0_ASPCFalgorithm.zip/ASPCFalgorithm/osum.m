function v = osum(x, obs)
    v = sum(x .* obs);
end