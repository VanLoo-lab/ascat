% 
% Threshold function (v. 16.2.2008)
%
% This algorithm is a supplement to the paper: Liest�l, Baumbusch, 
% B�rresen-Dale and Lingj�rde. Outliers and detection of copy number 
% changes (2008).
%

function xwin = psi(x,c)
xwin = x;
xwin(x < -c) = -c;
xwin(x > c) = c;
