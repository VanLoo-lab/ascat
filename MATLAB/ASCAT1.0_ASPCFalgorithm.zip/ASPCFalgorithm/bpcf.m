% 
% Bivariate PCF filter for aCGH data (v. 12.03.2009)
%
%

function [yhat1, yhat2, t] = bpcf(t1, y01, sd1, t2, y02, sd2, kmin, gamma)

% Mean-center response variables
ymean1 = mean(y01);
y01 = y01 - ymean1;
ymean2 = mean(y02);
y02 = y02 - ymean2;

% Create vector t of unique design points as well as two associated
% vectors y1 and y2 with response values (may be missing for one
% of the two, but never for both) and two associated vectors m1 and m2 
% giving missing status

t = unique([t1;t2]);
N = numel(t);
y1 = zeros(1,N);
y2 = zeros(1,N);
m1 = zeros(1,N);  % 0 = missing, 1 = observed
m2 = zeros(1,N);  % 0 = missing, 1 = observed
for i = 1:N
    k1 = find(t1==t(i));
    k2 = find(t2==t(i));
    if numel(k1) > 0 
        y1(i) = y01(k1);
        m1(i) = 1;
    end
    if numel(k2) > 0
        y2(i) = y02(k2);
        m2(i) = 1;
    end
end

yhat1 = zeros(N,1);
yhat2 = zeros(N,1);

% Data are in y1(1..N) and y2(1..N)

% Very short sequences are estimated by average
if N == 1
    yhat1(1) = y1(1);
    yhat2(1) = y2(1);
    return
end

kminBoth = coverRightBoth(kmin, 1, m1, m2);
kminBoth2 = coverRightBoth(2*kmin, 1, m1, m2);

if N < kminBoth2;
    yhat1 = repmat(omean(y1,m1),N,1);
    yhat2 = repmat(omean(y2,m2),N,1);
    return
end

% Find initSum, initKvad, initAve for segment y[1..kmin]
initSum1 = sum(y1(1:kminBoth));
initKvad1 = sum(y1(1:kminBoth).^2);
initAve1 = initSum1/sum(m1(1:kminBoth));
initSum2 = sum(y2(1:kminBoth));
initKvad2 = sum(y2(1:kminBoth).^2);
initAve2 = initSum2/sum(m2(1:kminBoth));

% Define vector of best costs
bestCost = zeros(N,1);
bestCost(kminBoth) = (initKvad1 - initSum1*initAve1)/sd1^2 + ...
                     (initKvad2 - initSum2*initAve2)/sd2^2;

% Define vector of best splits
bestSplit = zeros(N,1);
bestSplit(kminBoth) = 0; % Previous (imaginary) segment ends at 0

% Define vector of best averages
bestAver1 = zeros(N,1);
bestAver2 = zeros(N,1);
bestAver1(1:kminBoth) = initAve1;
bestAver2(1:kminBoth) = initAve2;

% Define auxiliary variables
newSum1 = initSum1;
newAver1 = initAve1;
newKvad1 = initKvad1;
newSSQ1 = 0;
newSum2 = initSum2;
newAver2 = initAve2;
newKvad2 = initKvad2;
newSSQ2 = 0;

% We have to treat the region y(1..2*kmin-1) separately, as it 
% cannot be split into two full segments
for k = kminBoth+1 : kminBoth2-1
   newSum1 = newSum1 + y1(k);
   newAver1 = newSum1 / sum(m1(1:k));
   newKvad1 = newKvad1 + y1(k)^2;
   newSSQ1 = newKvad1 - newSum1*newAver1;
   newSum2 = newSum2 + y2(k);
   newAver2 = newSum2 / sum(m2(1:k));
   newKvad2 = newKvad2 + y2(k)^2;
   newSSQ2 = newKvad2 - newSum2*newAver2;
   bestCost(k) = newSSQ1/sd1^2 + newSSQ2/sd2^2;
   bestSplit(k) = 0; % Previous (imaginary) segments ends at 0
   bestAver1(k) = newAver1;
   bestAver2(k) = newAver2;
end

for n = kminBoth2 : N
   % Now bestCost(r) is the optimal value over y(1..r), r = 1..n-1
   % We want to find bestCost(n). To do this, we seek the best
   % split y(1..n) = y(1..j-1) + y(j..n) where the latter is
   % a primitive segment. We refer to j-1 as the split point.
   % Allowed split points are {kmin..n-kmin}
   
   % First consider split = n-kmin with 
   % bestCost(n) = bestCost(n-kmin) + ssq + gamma
   n0 = coverLeftBoth(kmin, n, m1, m2);
   newSum1 = sum(y1(n0:n));
   newKvad1 = sum(y1(n0:n).^2);
   newAver1 = newSum1 / sum(m1(n0:n));
   newSSQ1 = newKvad1 - newSum1 * newAver1;
   newSum2 = sum(y2(n0:n));
   newKvad2 = sum(y2(n0:n).^2);
   newAver2 = newSum2/ sum(m2(n0:n));
   newSSQ2 = newKvad2 - newSum2 * newAver2;
   
   aver1 = newAver1;
   aver2 = newAver2;
   
   split = n0 - 1;  % Best split so far
   cost = bestCost(n0-1) + newSSQ1/sd1^2 + newSSQ2/sd2^2 + gamma;
   
   % Now consider remaining splits {kmin..n-kmin-1}
   for j = n0-1:-1:kminBoth+1  % j = left endpoint of last segment
      % Consider split y(1..j-1) + y(j..n) where the latter is primitive
      y1j = y1(j);
      newSum1 = newSum1 + y1j;
      newAver1 = newSum1 / sum(m1(j:n));
      newKvad1 = newKvad1 + y1j^2;
      newSSQ1 = newKvad1 - newSum1 * newAver1;
      y2j = y2(j);
      newSum2 = newSum2 + y2j;
      newAver2 = newSum2 / sum(m2(j:n));
      newKvad2 = newKvad2 + y2j^2;
      newSSQ2 = newKvad2 - newSum2 * newAver2;
      newCost = bestCost(j-1) + newSSQ1/sd1^2 + newSSQ2/sd2^2 + gamma;
      if newCost < cost
         split = j-1;
         cost = newCost;
         aver1 = newAver1;
         aver2 = newAver2;
      end
   end
   
   % Best split is y(1..split) + y(split+1..n) under the condition
   % that kmin <= split <= n - kmin. We check if not making a
   % split is better
   totAver1 = (newSum1 + initSum1) / sum(m1(1:n));
   totAver2 = (newSum2 + initSum2) / sum(m2(1:n));
   totCost1 = (newKvad1 + initKvad1) - sum(m1(1:n))*totAver1^2;
   totCost2 = (newKvad2 + initKvad2) - sum(m2(1:n))*totAver2^2;
   totCost = totCost1/sd1^2 + totCost2/sd2^2;
   if totCost < cost
       split = 0;
       cost = totCost;
       aver1 = totAver1;
       aver2 = totAver2;
   end
   
   % We now have the optimal split of y(1..n)
   bestCost(n) = cost;
   bestAver1(n) = aver1;
   bestAver2(n) = aver2;
   bestSplit(n) = split;
end

% Trace back
n = N;
nlevels = 0;
while n > 0
   yhat1(bestSplit(n)+1:n) = bestAver1(n);
   yhat2(bestSplit(n)+1:n) = bestAver2(n);
   n = bestSplit(n);
   nlevels = nlevels + 1;    
end

yhat1 = ymean1 + yhat1;
yhat2 = ymean2 + yhat2;


