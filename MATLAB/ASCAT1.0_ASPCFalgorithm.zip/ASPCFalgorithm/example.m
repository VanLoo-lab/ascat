%%%% Example 1 (simulated data)
% This example illustrates the general bivariate PCF algorithm
% on two samples (t1,y1) and (t2,y2) where the number of probes and
% their genomic positions are different for the two samples.

n1 = 100;
t1 = sort(randn(n1,1));
t1 = t1 - min(t1);
y1 = (t1 < 1.5) .* 1 + 0.2 * randn(n1,1);

n2 = 120;
t2 = sort(randn(n2,1));
t2 = t2 - min(t2);
y2 = (t2 < 1.5) .* 1 + 0.2 * randn(n2,1);

kmin = 6;
gamma0 = 12;

[yhat1, yhat2, t] = ebpcf(t1, y1, 0.2, t2, y2, 0.2, kmin, gamma0);

figure
subplot(2,1,1)
plot(t1, y1, '.')
hold on
plot(t, yhat1, '-');

subplot(2,1,2)
plot(t2, y2, '.')
hold on
plot(t, yhat2, '-');

%%%% Example 2 (data from Peter)
% This example illustrates the application of the bivariate PCF algorithm
% on Illumina (logR, B-allele)-data. 

logR = readtable('C:\Ole Chr\DNR\Peter\Example.txt', 2, 2, 'decimal', 1366);
allB = readtable('C:\Ole Chr\DNR\Peter\Example.txt', 3, 3, 'decimal', 1366);
[yhat1, yhat2] = aspcf(logR, allB, 6, 12);
p = size(logR, 1);
t = (1:p)';

% Winsorize logR data
[logRwins logRsdev] = pcfwins(logR, 2.5, 5, 1);

% Flip B-allele data around the line y = 0.5 and winsorize
allBflip = allB;
allBflip(allB > 0.5) = 1 - allB(allB > 0.5);
[allBwins allBsdev] = pcfwins(allBflip, 2.5, 5, 1);

% Run bivariate PCF
kmin = 6;
gamma0 = 12;
k0 = unifrnd(0,1,numel(t),1) >= 0.95;
t0 = t(k0);
logRwins = logRwins(k0);
[yhat1, yhat2, t] = ebpcf(t0, logRwins, logRsdev, ...
                         t, allBwins, allBsdev, ...
                         kmin, gamma0);

% On each segment compute sd of unflipped B allele data
dy = diff(yhat2);
frst = [1; 1+find(dy ~= 0)];
last = [find(dy ~= 0); p];
nseg = numel(frst);
res = zeros(nseg,2);
for i = 1:nseg
   yi1 = allB(frst(i):last(i));
   yi2 = allBflip(frst(i):last(i))-yhat2(frst(i):last(i)); 
   [h,pval] = kstest((yi1-0.5)/allBsdev);
   if pval > 0.05
      yhat2(frst(i):last(i)) = 0.5;
      ['Segment ' num2str(i) ': ' num2str(1.4826*mad(yi1,1)) ...
       ' - ' num2str(1.4826*mad(yi2,1)) ' pval = ' num2str(pval) ' NS'] 
   else
       ['Segment ' num2str(i) ': ' num2str(1.4826*mad(yi1,1)) ...
       ' - ' num2str(1.4826*mad(yi2,1)) ' pval = ' num2str(pval)]
   end
   res(i,:) = [1.4826*mad(yi1,1), 1.4826*mad(yi2,1)];
end

% Plot result
figure

subplot(2,1,1)
plot(t, allB, '.')
hold on
plot(t, yhat2, '-');
plot(t, 1-yhat2, '-');

subplot(2,1,2)
plot(t0, logRwins, '.')
hold on
plot(t, yhat1, '-');

%%%% Example 3 (data from Peter)
% This example illustrates the application of the allele specific PCF 
% algorithm. 

logR = readtable('lr.txt', 1, 1, 'decimal', 4078);
allB = readtable('baf.txt', 1, 1, 'decimal', 4078);
[yhat1, yhat2] = aspcf(logR, allB, 6, 12);

% Plot result
figure

N = numel(allB);
x = 1:N;

subplot(2,1,1)
ok = allB >= 0;
plot(x(ok), allB(ok), '.')
hold on
plot(x, yhat2, '-');
plot(x, 1-yhat2, '-');

subplot(2,1,2)
plot(x, logR, '.')
hold on
plot(x, yhat1, '-');

