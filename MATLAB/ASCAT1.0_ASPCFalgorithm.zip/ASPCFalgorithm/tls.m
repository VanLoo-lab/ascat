function X = tls(A,B)
  
 n = size(A,2);
 C = [A B];
 [U S V] = svd(C,0);
 V12 = V(1:n,1+n:end);
 V22 = V(1+n:end,1+n:end);
 X = -V12/V22;
